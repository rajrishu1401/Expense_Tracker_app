import 'package:flutter/material.dart';
import 'package:expense_tracker/models/expense.dart';
import 'package:expense_tracker/widget/expenses_list/expenses_item.dart';

class ExpensesList extends StatelessWidget{
  const ExpensesList({super.key,required this.expenses,required this.removeExpense});
  final void Function(int index) removeExpense;
  final List<Expense> expenses;
  @override
  Widget build(BuildContext context) {
    return ListView.builder(itemCount: expenses.length,itemBuilder: (ctx,index)=>Dismissible(
      background: Container(
        alignment: Alignment.centerRight,
        color: Theme.of(context).colorScheme.error.withOpacity(0.2),
        margin: EdgeInsets.symmetric(horizontal: Theme.of(context).cardTheme.margin!.horizontal),
        child: const Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: [
              Icon(Icons.delete),
              Spacer(),
              Icon(Icons.delete),
            ],
          ),
        ),
      ),
      key: ValueKey(expenses[index]),
        onDismissed: (direction){
        removeExpense(index);
        },
        child: ExpenseItem(expenses[index])));
  }
}