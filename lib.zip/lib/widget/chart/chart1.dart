import 'package:expense_tracker/models/expense.dart';
import 'package:flutter/material.dart';

class Chart1 extends StatefulWidget{
  const Chart1(this.expenses,{super.key});
  final List<Expense> expenses;
  @override
  State<Chart1> createState() {
    return _Chart1State();
  }
}


class _Chart1State extends State<Chart1>{
  Widget chart(double maxTotal,bool isDarkMode){
    if(widget.expenses.isEmpty){
      return const Text('');
    }
    else{
      return Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: barChart(maxTotal,isDarkMode),
      );
    }
  }

  List<Widget> barChart(double maxTotal,bool isDarkMode){
    List<Widget> bar=[];
    for (final category in Category.values){
      var total=ExpenseBucket.forCategory(widget.expenses,category).totalExpenses;
      total=total==0?0:(total/maxTotal);
      bar.add(Container(
        decoration: BoxDecoration(
          shape: BoxShape.rectangle,
          borderRadius:const BorderRadius.vertical(top: Radius.circular(8)),
          color: isDarkMode?Theme.of(context).colorScheme.secondary
              : Theme.of(context).colorScheme.primary.withOpacity(0.65),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child:FractionallySizedBox(
            heightFactor:total,
        )
        ),
      )
      );
    }
    return bar;
  }
  @override
  Widget build(BuildContext context) {
    final isDarkMode=MediaQuery.of(context).platformBrightness==Brightness.dark;
    var maxTotal=0.0;
    for (final category in Category.values){
      var total=ExpenseBucket.forCategory(widget.expenses,category).totalExpenses;
      if(total>maxTotal){
        maxTotal=total;
      }
    }
    return Container(
      margin: const EdgeInsets.all(16),
      height: 200,
      width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          gradient: LinearGradient(
            colors: [
              Theme.of(context).colorScheme.primary.withOpacity(0.3),
              Theme.of(context).colorScheme.primary.withOpacity(0.0)
            ],
            begin: Alignment.bottomCenter,
            end: Alignment.topCenter,
          ),
        ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          const SizedBox(
            height: 10,
          ),
          Expanded(child: Center(child: chart(maxTotal,isDarkMode))),
           const SizedBox(
             height: 10,
           ),
           Padding(
             padding: const EdgeInsets.only(bottom: 20),
             child: Row(
               crossAxisAlignment: CrossAxisAlignment.end,
               mainAxisAlignment: MainAxisAlignment.spaceAround,
               children: [
                 for (final pic in Category.values)
                   Icon(
                     categoryIcon[pic],
                     color: isDarkMode?Theme.of(context).colorScheme.secondary
                         : Theme.of(context)
                         .colorScheme
                         .primary
                         .withOpacity(0.7),
                   ),
               ],
             ),
           )
        ],
      )
    );
  }
}