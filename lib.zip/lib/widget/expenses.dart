import 'package:flutter/material.dart';
import 'package:expense_tracker/models/expense.dart';
import 'package:expense_tracker/widget/expenses_list/expenses_list.dart';
import 'package:expense_tracker/widget/new_expense.dart';
import 'package:expense_tracker/widget/chart/chart1.dart';

class Expenses extends StatefulWidget{
  const Expenses({super.key});
  @override
  State<Expenses> createState() {
    return _ExpensesState();
  }
}

class _ExpensesState extends State<Expenses>{
  final List<Expense> _registeredExpenses=[];
  void _openAddExpenseOverlay(){
    showModalBottomSheet(
      useSafeArea: true,
      isScrollControlled: true,
      context: context, builder: (ctx)=>NewExpense(_registeredExpenses,_setState),
    );
  }
  void _removeExpense(int index){
    final Expense removedExpense=_registeredExpenses[index];
    _registeredExpenses.removeAt(index);
    setState(() {
    });
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Expense Removed'),
      duration: const Duration(seconds: 5),
      action:SnackBarAction(label:'Undo', onPressed:(){
        _registeredExpenses.insert(index, removedExpense);
        setState(() {
        });
      }),
    ),
    );
  }
  void _setState(){
    setState(() {
    });
  }
  @override
  Widget build(BuildContext context) {
    var width=MediaQuery.of(context).size.width;
    Widget mainContent=const Center(child:Text('No expense to show!'));
    if (_registeredExpenses.isNotEmpty){
      mainContent=ExpensesList(expenses:_registeredExpenses,removeExpense: _removeExpense,);
    }
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('The Expense Tracker'),
          //backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          actions: [
            IconButton(onPressed:_openAddExpenseOverlay,
                icon: const Icon(Icons.add,))
          ],
        ),
        body:width<600?Column(
          children:[
            Chart1(_registeredExpenses),
            Expanded(child:mainContent),
          ],
        )
            :Row(
              children:[
                Expanded(child:Chart1(_registeredExpenses)),
                Expanded(child:mainContent),
              ]
            ),
      ),
    );
  }

}